import arcpy
import math
from arcpy import env
from numpy import*



class SGT(object):
    """Statistics of glacier termini changes"""
    def __init__(self):
        self.label = "Statistics of Glacier Termini Changes"
        self.description =  ("A GIS tool to calculate statistics of glacier termini changes")
        self.canRunInBackground = False
    def getParameterInfo(self):
        """Define the tool parameters."""
        # Input parameter 1
        gtg = arcpy.Parameter(
            displayName="Glacier termini workspace (file geodatabase or catalog)",
            name="gtg",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input")
        gtg.filter.list=["File System","Local Database"]
        # Output parameter 2
        mm = arcpy.Parameter(
            displayName="Wildcard of input point layers (any_prefix*)",
            name="mm",
            datatype="GPString",
            parameterType="Required",
            direction="Input")
        # Output parameter 3
        mmt = arcpy.Parameter(
            displayName="Name of output table (without extension)",
            name="mmt",
            datatype="GPString",
            parameterType="Required",
            direction="Output")


        parameters=[gtg,mm,mmt]
        return parameters
    def updateParameters(self, parameters):
        """Modify the values and properties of parameters before internal
        validation is performed.  This method is called whenever a parameter
        has been changed."""
        return

    def updateMessages(self, parameters):
        """Modify the messages created by internal validation for each tool
        parameter.  This method is called after internal validation."""
        return
    def execute(self, parameters, messages):
        try:
            # input parameters
            worksp=parameters[0].valueAsText # workspace
            swildcard=parameters[1].valueAsText # point layers wildcard
            outtab=parameters[2].valueAsText # table name
            errr=0
            # test geodatabase or shp
            in_gdb=0
            t_in = worksp[-4:]
            if t_in.upper()==".GDB" or t_in==".MDB":
                in_gdb=1
            if in_gdb==0:
                outputtab1=worksp+"\\"+outtab+".dbf"

            else:
                outputtab1=worksp+"\\"+outtab


            #  create list of all point layers of project
            env.workspace=worksp
            env.overwriteOutput=True
            lista=arcpy.ListFeatureClasses(swildcard,"point")
            #print lista
            nnnlista=len(lista)
            if nnnlista==0:
                errr=1
            mess='Points layers'+' '+str(nnnlista)
            arcpy.AddMessage(mess)
            for jj in range(0,nnnlista):
                mess=lista[jj]
                arcpy.AddMessage(mess)

            # merge all layers to temp1 layer in memory
            ss_mem="in_memory/"
            temp1=ss_mem+"t1"
            arcpy.Merge_management(lista, temp1)
            mess='Point layers merged in memory  OK'
            arcpy.AddMessage(mess)
            # summary stst table
            statsFields=[["Days","FIRST"],["Mo_r","MIN"],["Mo_r","MAX"],["Mo_r","MEAN"],
            ["Mo_r","STD"],["YY_f","FIRST"],["MM_f","FIRST"],["DD_f","FIRST"],
            ["YY_t","FIRST"],["MM_t","FIRST"],["DD_t","FIRST"],]
            caseField="Id"
            arcpy.Statistics_analysis(temp1, outputtab1, statsFields, caseField)
            arcpy.AddField_management(outputtab1,"Accum_time", "FLOAT")
            arcpy.AddField_management(outputtab1,"Weight_STA", "FLOAT")
            mess='Statistics tool, creating output table  OK'
            arcpy.AddMessage(mess)
            #arcpy.AddMessage(outputtab1)
            # sum of days
            sumdays=0;nn=0
            with arcpy.da.SearchCursor(outputtab1,["FIRST_Days"]) as cursor:
                for row in cursor:
                    sumdays=row[0]+sumdays
                    nn+=1
                del cursor
            errrb=str(nn)
            #arcpy.AddMessage(errrb)
            # numpy table to store: days, weigted mean, weighted std, cumul. days
            ttt=zeros((nn,4),float)

            # calculate weigted mean and std (for all records)
            i=0
            with arcpy.da.SearchCursor(outputtab1,["FIRST_Days","MEAN_Mo_r","STD_Mo_r"]) as cursor:
                for row in cursor:
                    ttt[i,0]=row[0]
                    ttt[i,1]=row[1]*row[0]/sumdays
                    ttt[i,2]=row[2]*row[0]/sumdays
                    i+=1
            del cursor
            errrb='Step2'
            #arcpy.AddMessage(errrb)
            # calculate cum. days
            time0=0
            time1=0
            for i in range(0,nn):
                time1=ttt[i,0]+time1
                time01=time0+(time1-time0)/2.0
                time0=time1
                ttt[i,3]=time01
            errrb='Step2b'
            #arcpy.AddMessage(errrb)
            with arcpy.da.SearchCursor(outputtab1,["FIRST_Days"]) as cursor:
                for row in cursor:
                    sumdays=row[0]+sumdays
            del cursor
            wmean=0
            wstd=0
            errrb='Step2c '+str(nn)
            #arcpy.AddMessage(errrb)
            for i in range(0,nn):
                wmean=wmean+ttt[i,1]
                wstd=wstd+ttt[i,2]
            errrb1='step3'
            #arcpy.AddMessage(errrb)
            # update rows in stat table
            i=0
            with arcpy.da.UpdateCursor(outputtab1,["Accum_time","Weight_STA"]) as cursor:
                for row in cursor:
                    if nn>2 and i==0:
                        row[1]=wmean
                    if nn>2 and i==1:
                        row[1]=wstd
                    row[0]=ttt[i,3]
                    cursor.updateRow(row)
                    i+=1
            del cursor

            arcpy.AddMessage('Tool successfully executed')
        except:
            errrb='Tool could not be successfully executed'
            arcpy.AddMessage(errrb)
            if errr==1:
                errrb='List of point layers is empty, check the wildcard'
                arcpy.AddMessage(errrb)