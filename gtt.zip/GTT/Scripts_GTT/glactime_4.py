import arcpy
import math
from arcpy import env
from numpy import*
import os
from datetime import date




class IGT(object):
    """Interpolate glacier termini for each day"""
    def __init__(self):
        self.label = "Interpolate Glacier Termini"
        self.description =  ("A GIS tool to interpolate glacier termini for each day")
        self.canRunInBackground = False
    def getParameterInfo(self):
        """Define the tool parameters."""
        # Input parameter 1
        gtg = arcpy.Parameter(
            displayName="Glacier termini workspace (file geodatabase or catalog)",
            name="gtg",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input")
        gtg.filter.list=["File System","Local Database"]
        # Input parameter 2
        ltg = arcpy.Parameter(
            displayName="Layer of  termini",
            name="ltg",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input")
        #ltg.parameterDependencies=[gtg.name]
        ltg.filter.list=["Polyline"]
        # Input parameter 3
        pdd = arcpy.Parameter(
           displayName="Points lag",
            name="pdd",
            datatype="GPLong",
            parameterType="Required",
            direction="Input")
        pdd.values=50
        pdd.filter.type="Range"
        pdd.filter.list=[1.0,1000.0]
        # Output parameter 4
        mm = arcpy.Parameter(
            displayName="First part of results name",
            name="mm",
            datatype="GPString",
            parameterType="Required",
            direction="Output")


        parameters=[gtg,ltg,pdd,mm]
        return parameters
    def updateParameters(self, parameters):
        """Modify the values and properties of parameters before internal
        validation is performed.  This method is called whenever a parameter
        has been changed."""
        return

    def updateMessages(self, parameters):
        """Modify the messages created by internal validation for each tool
        parameter.  This method is called after internal validation."""
        return
    def execute(self, parameters, messages):
        try:
            # input parameters
            ICE_geobase=parameters[0].valueAsText # workspace
            ICE_layer=parameters[1].valueAsText # termini layer
            krok=parameters[2].value # lag of points
            name=parameters[3].valueAsText # prefix name

            logfile=0      # 0 - swith off, 1 - switch on for testing  D:\temp\name.txt
            # end of parameters




            # test geodatabase or shp
            in_gdb=0
            t_in = ICE_geobase[-4:]

            if t_in.upper()==".GDB" or t_in==".MDB":
                in_gdb=1


            xytab1=zeros((1000,2),float)
            xytab2=zeros((1000,2),float)
            ptab1=zeros((1000,2),int)
            ptab2=zeros((1000,2),int)
            ppp12=zeros((1000,7),float) # OBID1,OBID2,X1,Y1,X2,Y2,DIST


            #*******************************************************************************
            def dyst(xs,ys,xc,yc): # dystans between two points xs,ys and xc,yc
                dx=xc-xs
                dy=yc-ys
                dd=math.sqrt(dx*dx+dy*dy)
                return dd

            #*******************************************************************************
            def xin(x1,x2,d12,d):  # interpolate xp in proportion d/d12 (d12 - distance from old to young point)
                dd=float(d)/d12
                xp=x1+(x2-x1)*dd
                return xp

            def yin(y1,y2,d12,d):  # interpolate yp  in proportion d/d12 (d12 - distance from old to young point)
                dd=float(d)/d12
                yp=y1+(y2-y1)*dd
                return yp
            #*******************************************************************************

            def test_ICE_layer(any_ice_layer):
                # Tests the ICE_layer and returns 2 tuples of (year,month,day,direction) for
                # older day and younger day
                def rfirst(y1,m1,d1,y2,m2,d2):
                    # test which date is older (return 1,2 or 0 if equal)
                    if y2>y1:
                        return 1
                    elif y1>y2:
                        return 2
                    elif m2>m1:
                        return 1
                    elif m1>m2:
                        return 2
                    elif d2>d1:
                        return 1
                    elif d1>d2:
                        return 2
                    else:
                        return 0
               # test fields of any_ice_layer
                testff=1
                listaff=arcpy.ListFields(any_ice_layer)
                fff=0
                for pole in listaff:
                    if pole.name=="GLACIER":
                        fff+=1
                    if pole.name=="DATE_YY":
                        fff+=1
                    if pole.name=="DATE_MM":
                        fff+=1
                    if pole.name=="DATE_DD":
                        fff+=1
                    if pole.name=="DIR":
                        fff+=1
                    if pole.name=="Id":
                        fff+=1
                if fff!=6:
                        testff=-2

                if testff==1:
                    with arcpy.da.SearchCursor(any_ice_layer,["SHAPE@XY","GLACIER","DATE_YY","DATE_MM","DATE_DD","DIR"]) as cur:
                        records_number=0;
                        glac1,yy1,mm1,dd1,dir1=0,0,0,0,"N"
                        glac2,yy2,mm2,dd2,dir2=0,0,0,0,"N"
                        for row in cur:
                            records_number+=1
                            if records_number==1:
                                glac1=row[1];yy1=row[2];mm1=row[3];dd1=row[4];dir1=row[5]
                            elif records_number==2:
                                glac2=row[1];yy2=row[2];mm2=row[3];dd2=row[4];dir2=row[5]
                    del cur
                    first_rec=rfirst(yy1,mm1,dd1,yy2,mm2,dd1)
                    if first_rec==1:
                        ymd1=(yy1,mm1,dd1,dir1)
                        ymd2=(yy2,mm2,dd2,dir2)
                    elif first_rec==2:
                        ymd2=(yy1,mm1,dd1,dir1)
                        ymd1=(yy2,mm2,dd2,dir2)
                    else:
                        ymd1=(0,0,0,"N")
                        ymd2=(0,0,0,"N")
                    return ymd1,ymd2
                else:
                    ymd1=(testff,0,0,"N")
                    ymd2=(0,0,0,"N")
                    return ymd1,ymd2
            #******************************************************************************
            def test_ICE_layer2(any_ice_layer):
                # Tests the ICE_layer and returns flag (testff-if all fields are present = 1) and list of n tables of (id,glacier,year,month,day,direction) for
                # sorted records starting from the oldest day and ends with the youngest day
                def rfirst(y1,m1,d1,y2,m2,d2):
                    # test which date is older (return 1,2 or 0 if equal)
                    if y2>y1:
                        return 1
                    elif y1>y2:
                        return 2
                    elif m2>m1:
                        return 1
                    elif m1>m2:
                        return 2
                    elif d2>d1:
                        return 1
                    elif d1>d2:
                        return 2
                    else:
                        return 0
               # test fields of any_ice_layer
                testff=1
                listaff=arcpy.ListFields(any_ice_layer)
                fff=0
                for pole in listaff:
                    if pole.name=="GLACIER":
                        fff+=1
                    if pole.name=="DATE_YY":
                        fff+=1
                    if pole.name=="DATE_MM":
                        fff+=1
                    if pole.name=="DATE_DD":
                        fff+=1
                    if pole.name=="DIR":
                        fff+=1
                    if pole.name=="Id":
                        fff+=1
                if fff!=6:
                        testff=-2
                tabtul=[]
                tabtulsort=[]

                if testff==1:

                    id=0
                    with arcpy.da.SearchCursor(any_ice_layer,["SHAPE@XY","GLACIER","DATE_YY","DATE_MM","DATE_DD","DIR"]) as cur:
                        records_number=0;
                        for row in cur:
                            records_number+=1
                            glac=row[1];yy=row[2];mm=row[3];dd=row[4];dir=row[5]
                            tul=[id,glac,yy,mm,dd,dir]
                            tabtul.append(tul)
                    del cur

                    # sort

                    for i in range(0,records_number):
                        id=1
                        for j in range(0,records_number):
                            if i!=j:
                                x=rfirst(tabtul[i][2],tabtul[i][3],tabtul[i][4],tabtul[j][2],tabtul[j][3],tabtul[j][4])
                                if x>1:
                                    id+=1
                        tabtul[i][0]=id

                    for i in range(1,records_number+1):
                        for j in range(0,records_number):
                            if tabtul[j][0]==i:
                                tul2=(tabtul[j][0],tabtul[j][1],tabtul[j][2],tabtul[j][3],tabtul[j][4],tabtul[j][5])
                                tabtulsort.append(tul2)
                    return testff,tabtulsort
                else:
                    return testff,tabtul

            #******************************************************************************
            def line_to_points(dirr,inlinia,krok,dostos,rew,outpoint):
                # function converts line to points (new layer)
                # dirr - workspace, inlinia - line layer, krok - distance between points,
                # dostos - (0,1) adjust to match first and last points with start and end of line
                # rew - (0,1) start points from end of line
                # outpoint - output points layer

                env.workspace = dirr

                vernum = 60000   # max number of  vertexes
                linnum = 1000   # max number of lines

                gtab1=zeros((vernum,2),float)  #
                gtab1b=zeros((vernum,2),float) #
                atab1=zeros((vernum),int)      #
                gtab2=zeros((vernum,2),float)  #
                atab2=zeros((vernum,2),int)    #
                ditab=zeros((linnum),float)    #
                aitab=zeros((linnum,3),int)    #
                # parametres definition

                if rew:
                    rewers=1
                else:
                    rewers=0
                if dostos:
                    adjust=1
                else:
                    adjust=0
                lpole="Id"   #
                eps=0.01 #

                def dyst(xs,ys,xc,yc):
                    dx=xc-xs
                    dy=yc-ys
                    dd=math.sqrt(dx*dx+dy*dy)
                    return dd

                def xin(x1,x2,d12,d):  #
                    dd=float(d)/d12
                    xp=x1+(x2-x1)*dd
                    return xp

                def yin(y1,y2,d12,d):  #
                    dd=float(d)/d12
                    yp=y1+(y2-y1)*dd
                    return yp



                #
                g1=0
                l1=0
                with arcpy.da.SearchCursor(inlinia, ["SHAPE@",lpole]) as cursor:
                    for row in cursor:
                        for part in row[0]:
                            llid=int(row[1])
                            sumdys=0.0
                            aitab[l1,0]=llid
                            aitab[l1,1]=g1
                            for pnt in part:
                                xx=pnt.X
                                yy=pnt.Y
                                gtab1[g1,0]=xx
                                gtab1[g1,1]=yy
                                if g1>aitab[l1,1]:
                                    segdys=dyst(gtab1[g1,0],gtab1[g1,1],gtab1[g1-1,0],gtab1[g1-1,1])
                                    sumdys+=segdys
                                atab1[g1]=llid
                                g1+=1
                            aitab[l1,2]=g1-1
                            ditab[l1]=sumdys
                            l1+=1


                if rewers==1:
                    for i in range (0,l1):
                        star=aitab[i,1];endd=aitab[i,2]+1
                        for j in range(star,endd):
                            gtab1b[j,0]=gtab1[j,0]
                            gtab1b[j,1]=gtab1[j,1]
                        k=1
                        for j in range(star,endd):
                            gtab1[j,0]=gtab1b[endd-k,0]
                            gtab1[j,1]=gtab1b[endd-k,1]
                            k+=1

                k=0    #
                idk=0   #
                okrok=krok
                for i in range(0,l1): #
                    start=aitab[i,1];koniec=aitab[i,2]
                    krok=okrok
                    if adjust==1:
                        rr=ditab[i]/float(krok)
                        if rr<1:
                            krok=okrok
                        else:
                            krok = ditab[i]/round(rr,0)

                    skrok=0   #
                    pskrok=krok  #
                    #
                    j=start+1
                    licznik=0
                    pierwszy=0
                    if i>0:
                        idk+=1
                    while j<=koniec :
                        licznik+=1
                        if (pierwszy==0):

                            gtab2[k,0]=gtab1[j-1,0];gtab2[k,1]=gtab1[j-1,1]
                            atab2[k,0]=aitab[i,0];atab2[k,1]=idk
                            k+=1
                            dd=dyst(gtab1[j-1,0],gtab1[j-1,1],gtab1[j,0],gtab1[j,1])
                            pierwszy=1
                        else:


                            dd=dyst(gtab2[k-1,0],gtab2[k-1,1],gtab1[j,0],gtab1[j,1])
                        skrok=dd+skrok

                        if (krok-skrok)>eps:

                            gtab2[k,0]=gtab1[j,0];gtab2[k,1]=gtab1[j,1]
                            atab2[k,0]=aitab[i,0];atab2[k,1]=idk
                            k+=1
                            pskrok=krok-skrok
                            j+=1

                        else:   #  (skrok-krok)>=eps

                            gtab2[k,0]=xin(gtab2[k-1,0],gtab1[j,0],dd,pskrok)
                            gtab2[k,1]=yin(gtab2[k-1,1],gtab1[j,1],dd,pskrok)
                            atab2[k,0]=aitab[i,0];atab2[k,1]=idk
                            k+=1;idk+=1
                            gtab2[k,0]=gtab2[k-1,0];gtab2[k,1]=gtab2[k-1,1]
                            atab2[k,0]=aitab[i,0];atab2[k,1]=idk
                            k+=1
                            pskrok=krok;skrok=0





                nowa=outpoint
                ppath,nowa2=os.path.split(outpoint)
                arcpy.CreateFeatureclass_management(dirr,nowa,"POINT", "","DISABLED","DISABLED",inlinia)

                arcpy.AddField_management(nowa,"LID","LONG")
                arcpy.AddField_management(nowa,"LL","LONG")
                korekta=0
                pold=-1
                with arcpy.da.InsertCursor(nowa,["SHAPE@XY","LID","LL"]) as cursor:
                    for i in range(0,k):
                        x=gtab2[i,0]
                        y=gtab2[i,1]
                        p1=atab2[i,1]
                        p2=atab2[i,0]
                        rr=(x,y)
                        if p1!=pold:
                            cursor.insertRow([rr,p1,p2])
                        pold=p1

                del cursor






                env.workspace=ICE_geobase
                return



            #*******************************************************************************
            def sideLR(ax,ay,bx,by,cx,cy):
                # check on which side of line ax,ay to bx,by is point cx,cy
                # return 0 on line, 1 left of line, -1 right of line

                m=(bx-ax)*(cy-ay)-(by-ay)*(cx-ax)
                if m>0:
                    return 1
                elif m<0:
                    return -1
                else:
                    return 0

            #*********************************************************************************
            def tab_OB_NEAR(point1,point2):

                 with arcpy.da.SearchCursor(point1,["SHAPE@XY","NEAR_FID"]) as cursor:
                    nn1=0
                    for row in cursor:
                        xytab1[nn1,0],xytab1[nn1,1]=row[0]
                        ptab1[nn1,0]=nn1+1;ppp12[nn1,0]=ptab1[nn1,0]
                        ptab1[nn1,1]=row[1]
                        nn1+=1
                 del cursor
                 #arcpy.AddMessage(str(nn1))
                 with arcpy.da.SearchCursor(point2,["SHAPE@XY","NEAR_FID"]) as cursor:
                    nn2=0
                    for row in cursor:
                        xytab2[nn2,0],xytab2[nn2,1]=row[0]
                        ptab2[nn2,0]=nn2+1
                        ptab2[nn2,1]=row[1]
                        nn2+=1
                 del cursor
                 # step 1 in ppp12[,1] input OBID if the nearest distance from
                 # OBID1 is  OBID2  and  from OBID2 is OBID1
                 for i in range(0,nn1):

                    if ptab2[ptab1[i,1]-1,1]==ppp12[i,0]:

                        ppp12[i,1]=ptab2[ptab1[i,1]-1,0]
                    if ppp12[0,1]<0.1:
                        ppp12[0,1]=ptab2[0,0]
                    if ppp12[nn1-1,1]<0.1:
                        ppp12[nn1-1,1]=ptab2[nn2-1,0]

                 # step 2
                 count_tab=zeros((1000,4),int)
                 flagstart=0
                 ii=0
                 for i in range(0,nn1-1):

                    if ppp12[i+1,1]<0.1 and flagstart==0:
                        count_tab[ii,0]=ppp12[i,0]
                        count_tab[ii,2]=ppp12[i,1]
                        flagstart=1
                    if ppp12[i+1,1]>0.1 and flagstart==1:
                        count_tab[ii,1]=ppp12[i+1,0]
                        count_tab[ii,3]=ppp12[i+1,1]
                        flagstart=0
                        ii+=1

                # step 3
                 ii=0
                 while count_tab[ii,0]>0:
                    k=1
                    for j in range(count_tab[ii,0],count_tab[ii,1]-1):
                        a1=count_tab[ii,0];b1=count_tab[ii,1]
                        a2=count_tab[ii,2];b2=count_tab[ii,3]
                        an=a1+k
                        k+=1
                        x=float(a2)+float(b2-a2)/float(b1-a1)*float(an-a1)
                        ppp12[an-1,1]=int(round(x))
                        #print "1",an,ppp12[an-1,1]

                    ii+=1
                # step 4
                 for i in range (0,nn1):
                    ppp12[i,2]=xytab1[i,0]
                    ppp12[i,3]=xytab1[i,1]
                    ppp12[i,4]=xytab2[int(ppp12[i,1]-1),0]
                    ppp12[i,5]=xytab2[int(ppp12[i,1])-1,1]
                    ppp12[i,6]=-1.0*dyst(ppp12[i,2],ppp12[i,3],ppp12[i,4],ppp12[i,5])
                # step 5
                 for i in range(1,nn1-1):
                    ppp12[i,6]=ppp12[i,6]*sideLR(ppp12[i-1,2],ppp12[i-1,3],ppp12[i+1,2],ppp12[i+1,3],ppp12[i,4],ppp12[i,5])
                    #print ppp12[i,0],ppp12[i,1],ppp12[i,2],ppp12[i,3],ppp12[i,4],ppp12[i,5],ppp12[i,6]
                 return nn1
            #***************************************************************************************
            def points_from_ppp12(wdir,name,geolayer,yy1,mm1,dd1,yy2,mm2,dd2):
                arcpy.CreateFeatureclass_management(wdir,name,"POINT","","DISABLED","DISABLED",geolayer)

                arcpy.AddField_management(name,"PointID","LONG")
                arcpy.AddField_management(name,"DIST","FLOAT")
                arcpy.AddField_management(name,"YY_f","SHORT")
                arcpy.AddField_management(name,"MM_f","SHORT")
                arcpy.AddField_management(name,"DD_f","SHORT")
                arcpy.AddField_management(name,"YY_t","SHORT")
                arcpy.AddField_management(name,"MM_t","SHORT")
                arcpy.AddField_management(name,"DD_t","SHORT")

                with arcpy.da.InsertCursor(name,["SHAPE@XY","PointID","DIST","YY_f","MM_f","DD_f","YY_t","MM_t","DD_t"]) as cursor:
                    for i in range(0,nn1):
                        x=ppp12[i,2]
                        y=ppp12[i,3]
                        p1=int(ppp12[i,0])
                        p2=ppp12[i,6]
                        rr=(x,y)
                        cursor.insertRow([rr,p1,p2,yy1,mm1,dd1,yy2,mm2,dd2])


                del cursor
            #****************************************************************************************
            def segments_from_ppp12(wdir,name,geolayer,yy1,mm1,dd1,yy2,mm2,dd2):
                arcpy.CreateFeatureclass_management(wdir,name,"POLYLINE","","DISABLED","DISABLED",geolayer)
                arcpy.AddField_management(name,"DIST","FLOAT")
                arcpy.AddField_management(name,"YY_f","SHORT")
                arcpy.AddField_management(name,"MM_f","SHORT")
                arcpy.AddField_management(name,"DD_f","SHORT")
                arcpy.AddField_management(name,"YY_t","SHORT")
                arcpy.AddField_management(name,"MM_t","SHORT")
                arcpy.AddField_management(name,"DD_t","SHORT")
                with arcpy.da.InsertCursor(name,["SHAPE@","DIST","YY_f","MM_f","DD_f","YY_t","MM_t","DD_t"]) as cursor2:
                    linearray=arcpy.Array()
                    point=arcpy.Point()
                    for i in range(0,nn1):
                        x1=ppp12[i,2];y1=ppp12[i,3];x2=ppp12[i,4];y2=ppp12[i,5]
                        ddd=ppp12[i,6]
                        point.X=x1;point.Y=y1;linearray.add(point)
                        point.X=x2;point.Y=y2;linearray.add(point)
                        nowy_rekord=arcpy.Polyline(linearray)
                        linearray.removeAll()
                        cursor2.insertRow([nowy_rekord,ddd,yy1,mm1,dd1,yy2,mm2,dd2])
                del cursor2
            #****************************************************************************************
            def nline_from_ppp12(wdir,name,geolayer,days,day,yy1,mm1,dd1):

                arcpy.CreateFeatureclass_management(wdir,name,"POLYLINE","","DISABLED","DISABLED",geolayer)
                arcpy.AddField_management(name,"YY","SHORT")
                arcpy.AddField_management(name,"MM","SHORT")
                arcpy.AddField_management(name,"DD","SHORT")
                with arcpy.da.InsertCursor(name,["SHAPE@","YY","MM","DD"]) as cursor2:
                    linearray=arcpy.Array()
                    point=arcpy.Point()
                    for i in range(0,nn1):
                        xx=xin(ppp12[i,2],ppp12[i,4],days,day)
                        yy=yin(ppp12[i,3],ppp12[i,5],days,day)

                        point.X=xx;point.Y=yy;
                        linearray.add(point)
                    nowy_rekord=arcpy.Polyline(linearray)
                    linearray.removeAll()
                    cursor2.insertRow([nowy_rekord,yy1,mm1,dd1])
                del cursor2
            #*****************************************************************************************
            #****************************************************************************************
            def nline_from_ppp12time(wdir,name,geolayer,days,y,m,d,flag):
                def time_plus1day(y,m,d):
                    day_in_month=[31,28,31,30,31,30,31,31,30,31,30,31]
                    day_in_month4=[31,29,31,30,31,30,31,31,30,31,30,31]
                    feb29=[1972,1976,1980,1984,1988,1992,1996,2000,2004,2008,2012,2016,2020,2024,2028]

                    leap_year=0
                    if y in feb29:
                        leap_year=1
                    if leap_year==0:
                        if d<day_in_month[m-1]:
                            d=d+1
                        else:
                            if m==12:
                                y=y+1
                                m=1
                                d=1
                            else:
                                m=m+1
                                d=1
                    else:
                         if d<day_in_month4[m-1]:
                            d=d+1
                         else:
                            if m==12:
                                y=y+1
                                m=1
                                d=1
                            else:
                                m=m+1
                                d=1

                    sy=str(y)
                    sd=str(d)
                    sm=str(m)
                    if len(sd)==1:
                        sd='0'+sd
                    if len(sm)==1:
                        sm='0'+sm
                    sss=sy+sm+sd
                    return int(sss),int(sy),int(sm),int(sd)

                if flag==1:
                    arcpy.CreateFeatureclass_management(wdir,name,"POLYLINE","","DISABLED","DISABLED",geolayer)
                    arcpy.AddField_management(name,"TIME","LONG")

                with arcpy.da.InsertCursor(name,["SHAPE@","TIME"]) as cursor2:
                    linearray=arcpy.Array()
                    point=arcpy.Point()
                    for j in range(0,days):
                        for i in range(0,nn1):
                            xx=xin(ppp12[i,2],ppp12[i,4],days,j)
                            yy=yin(ppp12[i,3],ppp12[i,5],days,j)

                            point.X=xx;point.Y=yy;
                            linearray.add(point)
                        nowy_rekord=arcpy.Polyline(linearray)
                        linearray.removeAll()
                        ttt,y,m,d=time_plus1day(y,m,d)
                        cursor2.insertRow([nowy_rekord,ttt])
                del cursor2
            #########################################################################################
            def to_ymd(sss):
                y=0;m=0;d=0
                s3=sss.split(",")
                if len(s3)==3:
                    if s3[0].isdigit() and s3[1].isdigit() and s3[2].isdigit():
                        y=int(s3[0]);m=int(s3[1]);d=int(s3[2])
                        if (y>1100 and y<2100 and m>=1 and m<=12 and d>=1 and d<=31):
                            return y,m,d
                        else:
                            return  0,0,0
                    else: return 0,0,0

                else: return 0,0,0

            def check_date(year, month, day):
                correctDate = None
                try:
                    newDate = datetime.datetime(year, month, day)
                    correctDate = True
                except ValueError:
                    correctDate = False
                return correctDate
            #########################################################################################

            env.workspace=ICE_geobase
            nn_all=0

            testff,tabff=test_ICE_layer2(ICE_layer)
            if testff==1:

                sflag=1   #start flag of output file
                for i in range(0,len(tabff)-1):
                    arcpy.Delete_management("in_memory")
                    nn1=0;nn2=0
                    # zerowanie tablic
                    xytab1.fill(0)
                    xytab2.fill(0)
                    ptab1.fill(0)
                    ptab2.fill(0)
                    ppp12.fill(0)
                    yyy1=tabff[i][2];mmm1=tabff[i][3];ddd1=tabff[i][4];dir1=tabff[i][5]
                    yyy2=tabff[i+1][2];mmm2=tabff[i+1][3];ddd2=tabff[i+1][4];dir2=tabff[i+1][5]
                    flag=0;part_days=0;dayss=0
                    d1=date(yyy1,mmm1,ddd1)
                    d2=date(yyy2,mmm2,ddd2)
                    delta21=d2-d1
                    dayss=delta21.days


                    ss_older="in_memory/older"
                    ss_younger="in_memory/younger"
                ##
                ##
                    where_c='DATE_YY='+str(yyy1)+ ' AND '+' DATE_MM='+str(mmm1)+' AND '+'DATE_DD='+str(ddd1)
                    arcpy.Select_analysis(ICE_layer, ss_older, where_c)
                    where_c='DATE_YY='+str(yyy2)+ ' AND '+' DATE_MM='+str(mmm2)+' AND '+'DATE_DD='+str(ddd2)
                    arcpy.Select_analysis(ICE_layer, ss_younger, where_c)
                ##
                ##
                ##        # create from both lines two sets of points, glacier on the left side of the sequence of points
                ##
                    with arcpy.da.SearchCursor(ss_older,["SHAPE@"]) as cursor:
                        for row in cursor:
                            xfirst=row[0].firstPoint.X
                            yfirst=row[0].firstPoint.Y
                            xlast=row[0].lastPoint.X
                            ylast=row[0].firstPoint.Y
                    del cursor

                    rew=0
                    if dir1=='N':
                        if xfirst<=xlast:
                            rew=0
                        else:
                            rew=1
                    if dir1=='S':
                        if xfirst<=xlast:
                            rew=1
                        else:
                            rew=0
                    if dir1=='W':
                        if yfirst<=ylast:
                            rew=0
                        else:
                             rew=1
                    if dir1=='E':
                        if yfirst<=ylast:
                            rew=1
                        else:
                            rew=0
                    elif dir1=='P':
                        rew=1
                    elif dir1=='L':
                        rew=0
                    #print rew
                    dostos=1;outpoint="opnkt1"
                    line_to_points("in_memory",ss_older,krok,dostos,rew,outpoint)

                    if dir2=='N':
                        if xfirst<=xlast:
                            rew=0
                        else:
                            rew=1
                    if dir2=='S':
                        if xfirst<=xlast:
                            rew=1
                        else:
                            rew=0
                    if dir2=='W':
                        if yfirst<=ylast:
                            rew=0
                        else:
                            rew=1
                    if dir2=='E':
                        if yfirst<=ylast:
                            rew=1
                        else:
                            rew=0
                    elif dir2=='P':
                        rew=1
                    elif dir2=='L':
                        rew=0


                    dostos=1;outpoint="opnkt2"
                    line_to_points("in_memory",ss_younger,krok,dostos,rew,outpoint)

                    ##        # add NEAR_DIST results to both sets of points

                    arcpy.Near_analysis("in_memory\opnkt1", "in_memory\opnkt2", "", "LOCATION", "")

                    arcpy.Near_analysis("in_memory\opnkt2", "in_memory\opnkt1", "", "LOCATION", "")

                    nn1=tab_OB_NEAR("in_memory\opnkt1","in_memory\opnkt2")
                    ##



                    if in_gdb==1:
                            namen=name+"_line"
                    else:
                            namen=name+"_line"+".shp"


                    nametest=ICE_geobase+"\\"+namen

                    if sflag==1:
                        if arcpy.Exists(nametest):
                            #arcpy.AddMessage('LAYERS  NOT  SAVED. Layers with this prefix already exist in geodatabase')
                            arcpy.Delete_management(nametest)

                    nline_from_ppp12time(ICE_geobase,namen,"in_memory\opnkt1",dayss,yyy1,mmm1,ddd1,sflag)
                    sflag=0

                arcpy.AddMessage('Tool successfully executed')
            else:
                arcpy.AddMessage('Input file does not contain all fields')
                #print 'Input file does not contain all fields'
        except:
            errrb='Tool could not be successfully executed'
            arcpy.AddMessage(errrb)
